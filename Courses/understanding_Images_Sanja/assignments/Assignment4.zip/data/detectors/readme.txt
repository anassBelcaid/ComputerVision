These models have been trained with Deformable Part-Based Model v5.
Cite: 
  @article{lsvm-pami,
  title = "Object Detection with Discriminatively Trained Part Based Models",
  author = "Felzenszwalb, P. F. and Girshick, R. B. and McAllester, D. and Ramanan, D.",
  journal = "IEEE Transactions on Pattern Analysis and Machine Intelligence",
  year = "2010", volume = "32", number = "9", pages = "1627--1645"}
